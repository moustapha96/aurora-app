-- Set is_founder to true for the current user
UPDATE public.profiles
SET is_founder = true
WHERE id = 'c1c3940a-409e-4aed-b5a3-a3a69a2885e8';