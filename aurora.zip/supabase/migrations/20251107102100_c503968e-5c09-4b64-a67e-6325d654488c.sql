-- Add country field to profiles table
ALTER TABLE public.profiles ADD COLUMN country TEXT;