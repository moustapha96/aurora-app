-- Set founder status for the user
UPDATE public.profiles 
SET is_founder = true 
WHERE id = '4999804f-6545-4e42-a306-6f81d9304b21';