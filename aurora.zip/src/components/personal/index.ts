// PersonalOnboarding removed - direct editing mode enabled
export { PersonalModule } from "./PersonalModule";
export { PersonalSports } from "./PersonalSports";
export { PersonalArtCulture } from "./PersonalArtCulture";
export { PersonalVoyages } from "./PersonalVoyages";
export { PersonalCollections } from "./PersonalCollections";
export { PersonalPhilosophie } from "./PersonalPhilosophie";
export { PersonalProjets } from "./PersonalProjets";
